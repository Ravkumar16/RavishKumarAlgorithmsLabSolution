package com.greatLearning.alorithms;

import java.util.Scanner;

public class driver {
	
	public static void main(String[] args) {

			Scanner myObj = new Scanner(System.in);
			System.out.println("Enter the number of transactions");
			int length = myObj.nextInt();
			int trans[] = new int[length];
			System.out.println("Enter transactions");
			for (int i =0 ; i<length; i++){
				trans[i] = myObj.nextInt();
				
			}

			System.out.println("Enter the No of target to be achieved");
			int targetCount = myObj.nextInt();
		while (targetCount !=0){
			boolean isTragetAchieved =false;
			int temp = 0;
			System.out.println("Enter the target to be achieved");
			int target = myObj.nextInt();
			for (int j= 0; j<length; j++){
				
				
				temp = temp+ trans[j];
				if (temp >=target){
					int k = j+1;
					System.out.println("Target achieved after " + k + " transactions");
					isTragetAchieved =true;
					break;
				}

			}
			if (!isTragetAchieved){
				System.out.println("Given target is not achieved");
			}
			targetCount--;
		}
	   
	}    

}
