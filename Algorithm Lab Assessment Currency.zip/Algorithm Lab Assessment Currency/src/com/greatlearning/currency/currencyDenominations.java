package com.greatlearning.currency;

public class currencyDenominations {

	public int denominations[];
	public int count = 0;

	public currencyDenominations(int length) {
		denominations = new int[length];
	}

	public void insert(int index, int element) {
		denominations[index] = element;
		count++;
	}

	public void sorting() {
		for (int y = 0; y <= denominations.length-1; y++) {
			for (int j = y + 1; j <= denominations.length-1; j++) {
				int temp;
				if (denominations[y] < denominations[j]) {
					temp = denominations[y];
					denominations[y] = denominations[j];
					denominations[j] = temp;
				}

			}
		}
	}
	
	public void printcurrency(){
		for (int i = 0; i <= denominations.length-1; i++) {
			
			System.out.println(denominations[i]  );
		}
	}
	
	
	public void getPayment(int x){
		int noteCount = 0;
		while (x!=0){
		for (int w =0; w<denominations.length; w++){
			
				
		
			if (denominations[w]<= x){
				noteCount = x/denominations[w];
				x = x -noteCount*denominations[w];
			System.out.println(denominations[w] + ":" + noteCount);
			}
		}
	}
	}
}
