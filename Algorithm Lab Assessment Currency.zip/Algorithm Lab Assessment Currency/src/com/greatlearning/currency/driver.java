package com.greatlearning.currency;

import java.util.Scanner;

public class driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner myObj = new Scanner(System.in);
		System.out.println("size of the Currency Denominations");
		int length = myObj.nextInt();
		currencyDenominations curren = new currencyDenominations(length);
		System.out.println("Enter Currency Denominations");
		for (int i = 0; i<length; i++){
			curren.insert(i, myObj.nextInt());
		}
		
		curren.sorting();
		curren.printcurrency();
		
		System.out.println("Enter Amount to be paid");
		int amount = myObj.nextInt();
		curren.getPayment(amount);
		
		

	}

}
